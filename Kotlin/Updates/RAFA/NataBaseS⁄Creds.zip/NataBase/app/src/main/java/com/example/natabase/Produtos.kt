package com.exemplo.natabase

data class Produto(
    val nome: String,
    val tipo: String,
    var quantidade: Int = 0
)

