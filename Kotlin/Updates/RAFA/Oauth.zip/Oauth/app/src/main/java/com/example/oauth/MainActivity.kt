package com.example.oauth

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task

class MainActivity : AppCompatActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var tvUserInfo: TextView
    private lateinit var btnSignIn: SignInButton
    private lateinit var btnSignOut: Button

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        Log.d("GoogleSignIn", "Activity result received. Result Code: ${result.resultCode}")
        if (result.resultCode == Activity.RESULT_OK) {
            Log.d("GoogleSignIn", "Result is RESULT_OK. Handling sign-in.")
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            handleSignInResult(task)
        } else {
            Log.e("GoogleSignIn", "Sign-in failed. Result Code is NOT OK: ${result.resultCode}. The user likely cancelled or there was a configuration error (SHA-1 mismatch). Check Google Cloud Console.")
            Toast.makeText(this, "Login cancelado/falhou. Verifique o Logcat.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvUserInfo = findViewById(R.id.tvUserInfo)
        btnSignIn = findViewById(R.id.btnGoogleSignIn)
        btnSignOut = findViewById(R.id.btnGoogleSignOut)

        // Configure Google Sign-In for basic sign-in
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        btnSignIn.setOnClickListener {
            signIn()
        }

        btnSignOut.setOnClickListener {
            signOut()
        }

        val account = GoogleSignIn.getLastSignedInAccount(this)
        updateUI(account)
    }

    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
        signInLauncher.launch(signInIntent)
    }

    private fun signOut() {
        // Sign out and revoke access for a clean state
        googleSignInClient.signOut().addOnCompleteListener(this) {
            googleSignInClient.revokeAccess().addOnCompleteListener(this) {
                Toast.makeText(this, "Sessão terminada", Toast.LENGTH_SHORT).show()
                updateUI(null)
            }
        }
    } 

    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            updateUI(account)
        } catch (e: ApiException) {
            val message = when (e.statusCode) {
                10 -> "Erro de developer (código 10). A combinação SHA-1/PackageName está correta, mas o Client ID está errado."
                else -> "Falha no login, código: ${e.statusCode}"
            }
            Log.e("GoogleSignIn", "signInResult:failed code=" + e.statusCode, e)
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            updateUI(null)
        }
    }

    private fun updateUI(account: GoogleSignInAccount?) {
        if (account != null) {
            tvUserInfo.text = "Bem-vindo, ${account.displayName}"
            btnSignIn.visibility = View.GONE
            btnSignOut.visibility = View.VISIBLE
        } else {
            tvUserInfo.text = getString(R.string.not_logged_in)
            btnSignIn.visibility = View.VISIBLE
            btnSignOut.visibility = View.GONE
        }
    }
}
