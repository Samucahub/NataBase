package com.example.oauth

import android.app.Application
import android.util.Log
import kotlin.system.exitProcess

class OauthApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            Log.e("OauthAppCrash", "Unhandled exception in thread ${thread.name}", e)
            // It'''s important to exit the process so the OS doesn'''t think the app is just frozen.
            exitProcess(1)
        }
    }
}
